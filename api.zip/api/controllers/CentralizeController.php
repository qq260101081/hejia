<?php
/**
 * Created by 260101081@qq.com
 * User: carl
 * Date: 16/11/25 下午4:56
 * 集中服务
 */

namespace api\controllers;

use yii\web\Controller;

class CentralizeController extends Controller
{
    public function actionIndex()
    {

        return $this->render('index', [

        ]);
    }
}