<?php
/**
 * Created by 260101081@qq.com
 * User: carl
 * Date: 16/11/25 下午4:56
 * 代购服务
 */

namespace api\controllers;

use yii\web\Controller;

class BehalfController extends Controller
{
    public function actionIndex()
    {

        return $this->render('index', [

        ]);
    }
}