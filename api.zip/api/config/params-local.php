<?php
/**
 * Created by 260101081@qq.com
 * User: carl
 * Date: 16/11/24 下午12:58
 */
return [
    //微信公众号开发配置
    'wechat' => [
        'token' => 'yangyan',
        'redirect_uri' => 'http://liusheji.com/api.php',
        'appid' => 'wx316e162de957e94b',
        'appsecret' => '7398b20656d85ddcb10813141cf4eb70',
        'mchid' => 'your mchid',
        'encodingAESKey' => 'V58vaI0D4IcIy5wvTqRFImE22SWWDEJ55AWt6GFF2AO',
        'notifyUrl' => 'wechat notify url',
    ],
    'imageUrl' => 'http://localhost/hejia/api/web/images/'
];