<?php
    $this->title = '学生影像';
/**
 * Created by 260101081@qq.com
 * User: carl
 * Date: 16/12/21 下午9:16
 */

?>


